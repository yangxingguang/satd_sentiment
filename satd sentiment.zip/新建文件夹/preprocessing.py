import enchant
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk import pos_tag
from nltk.corpus import wordnet
from nltk.tokenize import TweetTokenizer
import pandas as pd
import re

wnl = WordNetLemmatizer()
USdict = enchant.Dict("en_US")
stoplist = set(stopwords.words('english'))

def remove_urls(vTEXT):
    vTEXT = re.sub(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', '', vTEXT, flags=re.MULTILINE)
    return (vTEXT)


def get_word(text):
    text = text.replace('.', ' ')
    tknzr = TweetTokenizer(strip_handles=True, reduce_len=True)
    rawwords = tknzr.tokenize(text)
    words = [word.lower() for word in rawwords]
    return words


def get_pos_word(words):
    def get_wordnet_pos(tag):
        if tag.startswith('J'):
            return wordnet.ADJ
        elif tag.startswith('V'):
            return wordnet.VERB
        elif tag.startswith('N'):
            return wordnet.NOUN
        elif tag.startswith('R'):
            return wordnet.ADV
        else:
            return None

    words = pos_tag(words)

    pos_word = [wnl.lemmatize(tag[0], pos=get_wordnet_pos(tag[1]) or wordnet.NOUN) for tag in words]

    cleanwords = [word for word in pos_word if word not in stoplist]

    return cleanwords
    
if __name__ == '__main__':
    df = pd.read_csv('./labeled_dataset.csv', encoding='ISO-8859-1')
    df = df.drop(df.columns[0:6], axis=1)
    df = df.drop(df.columns[8:13], axis=1)
    df['Comment'] = df['Comment'].apply(remove_urls)

    df['Comment'] = df['Comment'].apply(get_word)

    df['Comment'] = df['Comment'].apply(get_pos_word)

    df = df[~(df['Comment'].str.len() == 0)]

    df['Comment'] = df['Comment'].apply(lambda x: ' '.join(x))

    df = df.sample(frac=1.0).reset_index(drop=True)

    df.to_csv("./labeled_dataset_0.csv", encoding='ISO-8859-1', index=None)
