# -*- coding: utf-8 -*-
import pandas as pd
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import make_pipeline

bow_vectorizer = CountVectorizer(max_df=0.80, min_df=2, max_features=5000)


tfidf_vectorizer = TfidfVectorizer(max_df=0.80, min_df=2, max_features=5000)

df = pd.read_csv("./labeled_dataset_0.csv", encoding='utf-8')
x=df['Comment']
y=df['Sentiment']

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=1)

Nb = MultinomialNB()
pipe = make_pipeline(bow_vectorizer, Nb)
pipe.fit(x_train, y_train)
#Svm = SGDClassifier()
#pipe = make_pipeline(tfidf_vectorizer, Svm)
#pipe.fit(x_train, y_train)

y_pred = pipe.predict(x_test)
df['pred'] = pd.Series(y_pred, index=x_test.index)
df.to_csv("./labeled_dataset_0.csv", encoding='utf-8', index=None)
print('Save successfully!')

print(metrics.classification_report(y_test, y_pred, zero_division=0))



    
